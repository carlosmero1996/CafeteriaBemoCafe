/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package VIsta;

import com.toedter.calendar.JDateChooser;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;

/**
 *
 * @author OWNER
 */
public class RegistrosdeFacturasGastosBalances extends javax.swing.JInternalFrame {

    /**
     * Creates new form RegistrosdeFacturasGastoCorriente1
     */
    public RegistrosdeFacturasGastosBalances() {
        initComponents();
    }
    
        
    public JButton getBtPrevisualizar() {
        return btPrevisualizar;
    }

    public void setBtPrevisualizar(JButton btPrevisualizar) {
        this.btPrevisualizar = btPrevisualizar;
    }

    public JButton getBtVerCategoria() {
        return btVerCategoria;
    }

    public void setBtVerCategoria(JButton btVerCategoria) {
        this.btVerCategoria = btVerCategoria;
    }

    public JComboBox<String> getCbProCate() {
        return cbProCate;
    }

    public void setCbProCate(JComboBox<String> cbProCate) {
        this.cbProCate = cbProCate;
    }

    public JDialog getJdGastos() {
        return jdGastos;
    }

    public void setJdGastos(JDialog jdGastos) {
        this.jdGastos = jdGastos;
    }

    public JDialog getJdProductos() {
        return jdProductos;
    }

    public void setJdProductos(JDialog jdProductos) {
        this.jdProductos = jdProductos;
    }

    public JRadioButton getRbEditar() {
        return rbEditar;
    }

    public void setRbEditar(JRadioButton rbEditar) {
        this.rbEditar = rbEditar;
    }

    public JRadioButton getRbGenerar() {
        return rbGenerar;
    }

    public void setRbGenerar(JRadioButton rbGenerar) {
        this.rbGenerar = rbGenerar;
    }

    public JTextField getTxtCodPro() {
        return txtCodPro;
    }

    public void setTxtCodPro(JTextField txtCodPro) {
        this.txtCodPro = txtCodPro;
    }

    public JTextPane getTxtPrevista() {
        return txtPrevista;
    }

    public void setTxtPrevista(JTextPane txtPrevista) {
        this.txtPrevista = txtPrevista;
    }

    public JTextField getTxtPronombre() {
        return txtPronombre;
    }

    public void setTxtPronombre(JTextField txtPronombre) {
        this.txtPronombre = txtPronombre;
    }

    public JTextField getTxtProprecio() {
        return txtProprecio;
    }

    public void setTxtProprecio(JTextField txtProprecio) {
        this.txtProprecio = txtProprecio;
    }

    public JButton getBtProModif() {
        return btProModif;
    }

    public void setBtProModif(JButton btProModif) {
        this.btProModif = btProModif;
    }

    public JButton getBtProdelete() {
        return btProdelete;
    }

    public void setBtProdelete(JButton btProdelete) {
        this.btProdelete = btProdelete;
    }

    public JButton getBtPronuevo() {
        return btPronuevo;
    }

    public void setBtPronuevo(JButton btPronuevo) {
        this.btPronuevo = btPronuevo;
    }

    public JTable getTbProductos() {
        return tbProductos;
    }

    public void setTbProductos(JTable tbProductos) {
        this.tbProductos = tbProductos;
    }

    public JTextField getTxtBusqueda() {
        return txtBusqueda;
    }

    public void setTxtBusqueda(JTextField txtBusqueda) {
        this.txtBusqueda = txtBusqueda;
    }

    public JLabel getLbModificar() {
        return lbModificar;
    }

    public void setLbModificar(JLabel lbModificar) {
        this.lbModificar = lbModificar;
    }

    public JLabel getLbNuevo() {
        return lbNuevo;
    }

    public void setLbNuevo(JLabel lbNuevo) {
        this.lbNuevo = lbNuevo;
    }

    public JButton getBtAgregarModi() {
        return btAgregarModi;
    }

    public void setBtAgregarModi(JButton btAgregarModi) {
        this.btAgregarModi = btAgregarModi;
    }

    public JButton getBtSalir() {
        return btSalir;
    }

    public void setBtSalir(JButton btSalir) {
        this.btSalir = btSalir;
    }

    public JLabel getLbMontostotalesGastos() {
        return lbMontostotalesGastos;
    }

    public void setLbMontostotalesGastos(JLabel lbMontostotalesGastos) {
        this.lbMontostotalesGastos = lbMontostotalesGastos;
    }

    public JLabel getLbtotalGastos() {
        return lbtotalGastos;
    }

    public void setLbtotalGastos(JLabel lbtotalGastos) {
        this.lbtotalGastos = lbtotalGastos;
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jdProductos = new javax.swing.JDialog();
        btVerCategoria = new javax.swing.JButton();
        btAgregarModi = new javax.swing.JButton();
        btSalir = new javax.swing.JButton();
        txtPronombre = new javax.swing.JTextField();
        txtProprecio = new javax.swing.JTextField();
        lbModificar = new javax.swing.JLabel();
        cbProCate = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtPrevista = new javax.swing.JTextPane();
        btPrevisualizar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtCodPro = new javax.swing.JTextField();
        rbGenerar = new javax.swing.JRadioButton();
        rbEditar = new javax.swing.JRadioButton();
        lbNuevo = new javax.swing.JLabel();
        lbopcionovligatorianombre = new javax.swing.JLabel();
        lbopcionobligatoriaprecio = new javax.swing.JLabel();
        lbopcionobligatorioselecco = new javax.swing.JLabel();
        btgCodProd = new javax.swing.ButtonGroup();
        jdGastos = new javax.swing.JDialog();
        txtcodG = new javax.swing.JTextField();
        lbTitulo = new javax.swing.JLabel();
        btAgregarModiG = new javax.swing.JButton();
        btSalirG = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        txtprecioG = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        lbFotoG = new javax.swing.JLabel();
        btCargarFotoG = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtdescripG = new javax.swing.JTextArea();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        dtFecha = new com.toedter.calendar.JDateChooser();
        lboodesgasto = new javax.swing.JLabel();
        Lboofotogasto = new javax.swing.JLabel();
        lboopreciogasto = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        txtBusqueda = new javax.swing.JTextField();
        btProdelete = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbProductos = new javax.swing.JTable();
        jButton24 = new javax.swing.JButton();
        btPronuevo = new javax.swing.JButton();
        btProModif = new javax.swing.JButton();
        btReporteProductos = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        lbTotalProd = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btEliminarGastoC = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        btNuevoGC = new javax.swing.JButton();
        btModiGastoC = new javax.swing.JButton();
        btReportesGastos = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        lbtotalGastos = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        cbFechasGastos = new javax.swing.JComboBox<>();
        dtDesdeGasato = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        lbdesdeGastos = new javax.swing.JLabel();
        lbhastaGastos = new javax.swing.JLabel();
        dtHastaGasto = new com.toedter.calendar.JDateChooser();
        jLabel27 = new javax.swing.JLabel();
        lbMontostotalesGastos = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbGastos = new javax.swing.JTable();
        btFechaGASTO = new javax.swing.JButton();
        lbErroresGasto = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btReportesVentas = new javax.swing.JButton();
        jButton43 = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabla_factura_registro = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        lbTotalventas = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        lbTotalvendido = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cbFechasVentas = new javax.swing.JComboBox<>();
        btFecha = new javax.swing.JButton();
        lbErrores = new javax.swing.JLabel();
        dtDesdeVentas = new com.toedter.calendar.JDateChooser();
        lblDesdeVentas = new javax.swing.JLabel();
        lbHastaVentas = new javax.swing.JLabel();
        dtHastaVentas = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        jButton37 = new javax.swing.JButton();

        jdProductos.setLocationByPlatform(true);
        jdProductos.setResizable(false);

        btVerCategoria.setText("VER CATEGORIAS");

        btAgregarModi.setText("AGREGAR");

        btSalir.setText("SALIR");

        txtProprecio.setPreferredSize(new java.awt.Dimension(7, 29));

        lbModificar.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 20)); // NOI18N
        lbModificar.setText("MODIFICAR PRODUCTO");

        jLabel4.setText("Nombre:");

        jLabel5.setText("Precio:");

        jScrollPane1.setViewportView(txtPrevista);

        btPrevisualizar.setText("Previsualizar");

        jLabel10.setText("Categoria;");

        jLabel11.setText("Codigo:");

        txtCodPro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodProActionPerformed(evt);
            }
        });

        rbGenerar.setSelected(true);
        rbGenerar.setText("Generar codigos aut.");

        rbEditar.setText("Editar codigo");

        lbNuevo.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 20)); // NOI18N
        lbNuevo.setText("NUEVO PRODUCTO");

        lbopcionovligatorianombre.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lbopcionovligatorianombre.setForeground(new java.awt.Color(255, 0, 0));

        lbopcionobligatoriaprecio.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lbopcionobligatoriaprecio.setForeground(new java.awt.Color(204, 0, 0));

        lbopcionobligatorioselecco.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lbopcionobligatorioselecco.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jdProductosLayout = new javax.swing.GroupLayout(jdProductos.getContentPane());
        jdProductos.getContentPane().setLayout(jdProductosLayout);
        jdProductosLayout.setHorizontalGroup(
            jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jdProductosLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jdProductosLayout.createSequentialGroup()
                        .addComponent(lbModificar)
                        .addGap(18, 18, 18)
                        .addComponent(lbNuevo))
                    .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jdProductosLayout.createSequentialGroup()
                            .addComponent(btSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btAgregarModi, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jdProductosLayout.createSequentialGroup()
                                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jdProductosLayout.createSequentialGroup()
                                        .addComponent(txtPronombre, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lbopcionovligatorianombre, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jdProductosLayout.createSequentialGroup()
                                        .addComponent(txtCodPro, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(rbGenerar)
                                        .addGap(18, 18, 18)
                                        .addComponent(rbEditar))))
                            .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jdProductosLayout.createSequentialGroup()
                                        .addGap(53, 53, 53)
                                        .addComponent(txtProprecio, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(lbopcionobligatoriaprecio, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jdProductosLayout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(307, 307, 307)
                                        .addComponent(jLabel10)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbProCate, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jdProductosLayout.createSequentialGroup()
                                    .addComponent(btPrevisualizar)
                                    .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jdProductosLayout.createSequentialGroup()
                                            .addGap(353, 353, 353)
                                            .addComponent(btVerCategoria))
                                        .addGroup(jdProductosLayout.createSequentialGroup()
                                            .addGap(314, 314, 314)
                                            .addComponent(lbopcionobligatorioselecco, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jdProductosLayout.setVerticalGroup(
            jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdProductosLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbGenerar)
                    .addComponent(rbEditar)
                    .addComponent(jLabel11)
                    .addComponent(txtCodPro, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jdProductosLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel4))
                    .addGroup(jdProductosLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(lbopcionovligatorianombre, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdProductosLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPronombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbProCate, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtProprecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(lbopcionobligatoriaprecio, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1)
                .addComponent(lbopcionobligatorioselecco, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btPrevisualizar)
                    .addComponent(btVerCategoria))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(jdProductosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btAgregarModi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        jdGastos.setLocationByPlatform(true);

        txtcodG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodGActionPerformed(evt);
            }
        });

        lbTitulo.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 20)); // NOI18N
        lbTitulo.setText("NUEVO GASTO");

        btAgregarModiG.setText("AGREGAR");

        btSalirG.setText("SALIR");

        jLabel21.setText("Codigo:");

        jLabel41.setText("Fecha:");

        jLabel6.setText("Foto de factura recibida por el proveedor");

        lbFotoG.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btCargarFotoG.setText("Cargar foto");

        txtdescripG.setColumns(20);
        txtdescripG.setRows(5);
        jScrollPane3.setViewportView(txtdescripG);

        jLabel42.setText("Descripción:");

        jLabel43.setText("Monto del gasto:");

        lboodesgasto.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lboodesgasto.setForeground(new java.awt.Color(255, 0, 0));

        Lboofotogasto.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        Lboofotogasto.setForeground(new java.awt.Color(255, 0, 0));

        lboopreciogasto.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lboopreciogasto.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jdGastosLayout = new javax.swing.GroupLayout(jdGastos.getContentPane());
        jdGastos.getContentPane().setLayout(jdGastosLayout);
        jdGastosLayout.setHorizontalGroup(
            jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jdGastosLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btSalirG, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jdGastosLayout.createSequentialGroup()
                        .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel42))
                        .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jdGastosLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jdGastosLayout.createSequentialGroup()
                                        .addGap(124, 124, 124)
                                        .addComponent(jLabel43)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtprecioG))
                                    .addGroup(jdGastosLayout.createSequentialGroup()
                                        .addComponent(txtcodG, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(35, 35, 35)
                                        .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdGastosLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lboodesgasto, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lboopreciogasto, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jdGastosLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btAgregarModiG, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                            .addComponent(lbFotoG, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21))
                    .addGroup(jdGastosLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btCargarFotoG, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Lboofotogasto, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdGastosLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbTitulo)
                .addGap(330, 330, 330))
        );
        jdGastosLayout.setVerticalGroup(
            jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdGastosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jdGastosLayout.createSequentialGroup()
                        .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btCargarFotoG, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Lboofotogasto, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(lbFotoG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jdGastosLayout.createSequentialGroup()
                        .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel21)
                                .addComponent(txtcodG, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel41)
                            .addComponent(dtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jdGastosLayout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(jLabel42))
                            .addGroup(jdGastosLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lboodesgasto, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(21, 21, 21)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdGastosLayout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(132, 132, 132))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdGastosLayout.createSequentialGroup()
                        .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lboopreciogasto, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jdGastosLayout.createSequentialGroup()
                                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtprecioG, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel43))
                                .addGap(18, 18, 18)
                                .addGroup(jdGastosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btSalirG, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btAgregarModiG, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(27, 27, 27))))
        );

        setClosable(true);
        setPreferredSize(new java.awt.Dimension(1660, 800));

        jTabbedPane1.setToolTipText("");
        jTabbedPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTabbedPane1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        jTabbedPane1.setFont(new java.awt.Font("Yu Gothic", 1, 16)); // NOI18N

        jLabel17.setText("Para buscar ingresa o el nombre, codigo, o categoria:");

        btProdelete.setText("Eliminar prod.");

        tbProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre del producto", "Precio Unitario", "Categoria", "Estado"
            }
        ));
        jScrollPane4.setViewportView(tbProductos);

        jButton24.setText("CARGAR DATOS");

        btPronuevo.setText("Nuevo producto");

        btProModif.setText("Modificar prod.");

        btReporteProductos.setText("GENERAR REPORTE");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setText("Hay");

        lbTotalProd.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbTotalProd.setText("00");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel23.setText("productos registrados.");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 451, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 729, Short.MAX_VALUE)
                .addComponent(btPronuevo)
                .addGap(30, 30, 30)
                .addComponent(btProdelete)
                .addGap(26, 26, 26)
                .addComponent(btProModif)
                .addGap(52, 52, 52))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4)
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton24)
                        .addGap(18, 18, 18)
                        .addComponent(btReporteProductos))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbTotalProd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel23)))
                .addContainerGap(1357, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btProdelete, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btPronuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btProModif, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtBusqueda))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(jLabel13)
                    .addComponent(lbTotalProd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btReporteProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Productos", jPanel4);

        btEliminarGastoC.setText("Eliminar gast.");

        jButton9.setText("CARGAR DATOS");

        btNuevoGC.setText("Nuevo gasto");

        btModiGastoC.setText("Modificar gast.");

        btReportesGastos.setText("GENERAR REPORTE");

        jLabel24.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel24.setText("Hay");

        lbtotalGastos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbtotalGastos.setText("00");

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel26.setText("gastos registrados.");

        cbFechasGastos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbFechasGastos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hoy", "Esta semana", "Este mes", "Periodo específico", "Día específico" }));

        jLabel1.setText("Busca los gastos en la fecha de:");

        lbdesdeGastos.setText("Desde:");

        lbhastaGastos.setText("Hasta:");

        jLabel27.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel27.setText("Total de gastos: $");

        lbMontostotalesGastos.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbMontostotalesGastos.setText("00");

        tbGastos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Descripcion", "Fecha", "Monto total.", "Foto"
            }
        ));
        jScrollPane2.setViewportView(tbGastos);

        btFechaGASTO.setText("Buscar por fecha");

        lbErroresGasto.setForeground(new java.awt.Color(255, 0, 51));
        lbErroresGasto.setText("Mensaje de error");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbtotalGastos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbMontostotalesGastos)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbFechasGastos, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btFechaGASTO, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbErroresGasto, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dtDesdeGasato, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbdesdeGastos))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbhastaGastos, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dtHastaGasto, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 640, Short.MAX_VALUE)
                .addComponent(btNuevoGC)
                .addGap(30, 30, 30)
                .addComponent(btEliminarGastoC)
                .addGap(26, 26, 26)
                .addComponent(btModiGastoC)
                .addGap(52, 52, 52))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton9)
                .addGap(18, 18, 18)
                .addComponent(btReportesGastos)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbFechasGastos, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btEliminarGastoC, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btNuevoGC, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btModiGastoC, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(15, 15, 15)
                        .addComponent(btFechaGASTO, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbdesdeGastos)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dtDesdeGasato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbhastaGastos)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dtHastaGasto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbErroresGasto)))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(jLabel24)
                    .addComponent(lbtotalGastos)
                    .addComponent(jLabel27)
                    .addComponent(lbMontostotalesGastos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btReportesGastos, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Gastos", jPanel1);

        btReportesVentas.setText("GENERAR REPORTE");

        jButton43.setText("CARGAR DATOS");

        tabla_factura_registro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FACTURA ID", "CLIENTE ID", "NOMBRES", "CEDULA", "FECHA", "TOTAL FACTURA"
            }
        ));
        jScrollPane6.setViewportView(tabla_factura_registro);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Hay");

        lbTotalventas.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbTotalventas.setText("00");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1058, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 125, Short.MAX_VALUE)
        );

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel14.setText("facturas registradas");

        lbTotalvendido.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbTotalvendido.setText("00");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel20.setText("Total de ventas:  $");

        jLabel3.setText("Busca los gastos en la fecha de:");

        cbFechasVentas.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbFechasVentas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hoy", "Esta semana", "Este mes", "Periodo específico", "Día específico" }));

        btFecha.setText("Buscar por fecha");

        lbErrores.setForeground(new java.awt.Color(255, 0, 51));
        lbErrores.setText("Mensaje de error");

        dtDesdeVentas.setDateFormatString("dd/MM/yyyy");

        lblDesdeVentas.setText("Desde:");

        lbHastaVentas.setText("Hasta:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane6))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbTotalventas)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbTotalvendido)))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbFechasVentas, javax.swing.GroupLayout.Alignment.TRAILING, 0, 238, Short.MAX_VALUE)
                            .addComponent(jLabel3)
                            .addComponent(btFecha, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dtDesdeVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDesdeVentas))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbHastaVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dtHastaVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(lbErrores, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton43)
                        .addGap(18, 18, 18)
                        .addComponent(btReportesVentas)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbFechasVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(lblDesdeVentas)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dtDesdeVentas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(lbHastaVentas)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dtHastaVentas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbErrores)))))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lbTotalventas)
                    .addComponent(jLabel14)
                    .addComponent(jLabel20)
                    .addComponent(lbTotalvendido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton43, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btReportesVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Ventas", jPanel2);

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        jLabel2.setText("Registros");

        jButton37.setText("SALIR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
            .addGroup(layout.createSequentialGroup()
                .addGap(708, 708, 708)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton37)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCodProActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodProActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodProActionPerformed

    private void txtcodGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodGActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcodGActionPerformed

    public ButtonGroup getBtgCodProd() {
        return btgCodProd;
    }

    public void setBtgCodProd(ButtonGroup btgCodProd) {
        this.btgCodProd = btgCodProd;
    }

    public JTable getTabla_factura_registro() {
        return tabla_factura_registro;
    }

    public void setTabla_factura_registro(JTable tabla_factura_registro) {
        this.tabla_factura_registro = tabla_factura_registro;
    }

    public JLabel getLbTotalProd() {
        return lbTotalProd;
    }

    public void setLbTotalProd(JLabel lbTotalProd) {
        this.lbTotalProd = lbTotalProd;
    }

    public JLabel getLbTotalventas() {
        return lbTotalventas;
    }

    public void setLbTotalventas(JLabel lbTotalventas) {
        this.lbTotalventas = lbTotalventas;
    }

    public JLabel getLbTotalvendido() {
        return lbTotalvendido;
    }

    public void setLbTotalvendido(JLabel lbTotalvendido) {
        this.lbTotalvendido = lbTotalvendido;
    }

    public JComboBox<String> getCbFechasGastos() {
        return cbFechasGastos;
    }

    public void setCbFechasGastos(JComboBox<String> cbFechasGastos) {
        this.cbFechasGastos = cbFechasGastos;
    }

    public JComboBox<String> getCbFechasVentas() {
        return cbFechasVentas;
    }

    public void setCbFechasVentas(JComboBox<String> cbFechasVentas) {
        this.cbFechasVentas = cbFechasVentas;
    }

    public JDateChooser getDtDesdeGasato() {
        return dtDesdeGasato;
    }

    public void setDtDesdeGasato(JDateChooser dtDesdeGasato) {
        this.dtDesdeGasato = dtDesdeGasato;
    }

    public JDateChooser getDtDesdeVentas() {
        return dtDesdeVentas;
    }

    public void setDtDesdeVentas(JDateChooser dtDesdeVentas) {
        this.dtDesdeVentas = dtDesdeVentas;
    }

    public JDateChooser getDtHastaGasto() {
        return dtHastaGasto;
    }

    public void setDtHastaGasto(JDateChooser dtHastaGasto) {
        this.dtHastaGasto = dtHastaGasto;
    }

    public JDateChooser getDtHastaVentas() {
        return dtHastaVentas;
    }

    public void setDtHastaVentas(JDateChooser dtHastaVentas) {
        this.dtHastaVentas = dtHastaVentas;
    }

    public JLabel getLbHastaVentas() {
        return lbHastaVentas;
    }

    public void setLbHastaVentas(JLabel lbHastaVentas) {
        this.lbHastaVentas = lbHastaVentas;
    }

    public JLabel getLbdesdeGastos() {
        return lbdesdeGastos;
    }

    public void setLbdesdeGastos(JLabel lbdesdeGastos) {
        this.lbdesdeGastos = lbdesdeGastos;
    }

    public JLabel getLbhastaGastos() {
        return lbhastaGastos;
    }

    public void setLbhastaGastos(JLabel lbhastaGastos) {
        this.lbhastaGastos = lbhastaGastos;
    }

    public JLabel getLblDesdeVentas() {
        return lblDesdeVentas;
    }

    public void setLblDesdeVentas(JLabel lblDesdeVentas) {
        this.lblDesdeVentas = lblDesdeVentas;
    }

    public JLabel getLbFotoG() {
        return lbFotoG;
    }

    public void setLbFotoG(JLabel lbFotoG) {
        this.lbFotoG = lbFotoG;
    }

    public JLabel getLbTitulo() {
        return lbTitulo;
    }

    public void setLbTitulo(JLabel lbTitulo) {
        this.lbTitulo = lbTitulo;
    }

    public JTable getTbGastos() {
        return tbGastos;
    }

    public void setTbGastos(JTable tbGastos) {
        this.tbGastos = tbGastos;
    }

    public JTextField getTxtcodG() {
        return txtcodG;
    }

    public void setTxtcodG(JTextField txtcodG) {
        this.txtcodG = txtcodG;
    }

    public JTextArea getTxtdescripG() {
        return txtdescripG;
    }

    public void setTxtdescripG(JTextArea txtdescripG) {
        this.txtdescripG = txtdescripG;
    }

    public JTextField getTxtprecioG() {
        return txtprecioG;
    }

    public void setTxtprecioG(JTextField txtprecioG) {
        this.txtprecioG = txtprecioG;
    }

    public JButton getBtAgregarModiG() {
        return btAgregarModiG;
    }

    public void setBtAgregarModiG(JButton btAgregarModiG) {
        this.btAgregarModiG = btAgregarModiG;
    }

    public JButton getBtCargarFotoG() {
        return btCargarFotoG;
    }

    public void setBtCargarFotoG(JButton btCargarFotoG) {
        this.btCargarFotoG = btCargarFotoG;
    }

    public JButton getBtEliminarGastoC() {
        return btEliminarGastoC;
    }

    public void setBtEliminarGastoC(JButton btEliminarGastoC) {
        this.btEliminarGastoC = btEliminarGastoC;
    }

    public JButton getBtModiGastoC() {
        return btModiGastoC;
    }

    public void setBtModiGastoC(JButton btModiGastoC) {
        this.btModiGastoC = btModiGastoC;
    }

    public JButton getBtNuevoGC() {
        return btNuevoGC;
    }

    public void setBtNuevoGC(JButton btNuevoGC) {
        this.btNuevoGC = btNuevoGC;
    }

    public JButton getBtSalirG() {
        return btSalirG;
    }

    public void setBtSalirG(JButton btSalirG) {
        this.btSalirG = btSalirG;
    }

    public JDateChooser getDtFecha() {
        return dtFecha;
    }

    public void setDtFecha(JDateChooser dtFecha) {
        this.dtFecha = dtFecha;
    }

    public JButton getBtFecha() {
        return btFecha;
    }

    public void setBtFecha(JButton btFecha) {
        this.btFecha = btFecha;
    }

    public JLabel getLbErrores() {
        return lbErrores;
    }

    public void setLbErrores(JLabel lbErrores) {
        this.lbErrores = lbErrores;
    }

    public JLabel getLbopcionobligatoriaprecio() {
        return lbopcionobligatoriaprecio;
    }

    public void setLbopcionobligatoriaprecio(JLabel lbopcionobligatoriaprecio) {
        this.lbopcionobligatoriaprecio = lbopcionobligatoriaprecio;
    }

    public JLabel getLbopcionobligatorioselecco() {
        return lbopcionobligatorioselecco;
    }

    public void setLbopcionobligatorioselecco(JLabel lbopcionobligatorioselecco) {
        this.lbopcionobligatorioselecco = lbopcionobligatorioselecco;
    }

    public JLabel getLbopcionovligatorianombre() {
        return lbopcionovligatorianombre;
    }

    public void setLbopcionovligatorianombre(JLabel lbopcionovligatorianombre) {
        this.lbopcionovligatorianombre = lbopcionovligatorianombre;
    }

    public JLabel getLboopreciogasto() {
        return lboopreciogasto;
    }

    public void setLboopreciogasto(JLabel lboopreciogasto) {
        this.lboopreciogasto = lboopreciogasto;
    }

    public JLabel getLboodesgasto() {
        return lboodesgasto;
    }

    public void setLboodesgasto(JLabel lboodesgasto) {
        this.lboodesgasto = lboodesgasto;
    }

    public JLabel getLboofotogasto() {
        return Lboofotogasto;
    }

    public void setLboofotogasto(JLabel Lboofotogasto) {
        this.Lboofotogasto = Lboofotogasto;
    }

    public JButton getBtFechaGASTO() {
        return btFechaGASTO;
    }

    public void setBtFechaGASTO(JButton btFechaGASTO) {
        this.btFechaGASTO = btFechaGASTO;
    }

    public JLabel getLbErroresGasto() {
        return lbErroresGasto;
    }

    public void setLbErroresGasto(JLabel lbErroresGasto) {
        this.lbErroresGasto = lbErroresGasto;
    }

    public JButton getBtReporteProductos() {
        return btReporteProductos;
    }

    public void setBtReporteProductos(JButton btReporteProductos) {
        this.btReporteProductos = btReporteProductos;
    }

    public JButton getBtReportesGastos() {
        return btReportesGastos;
    }

    public void setBtReportesGastos(JButton btReportesGastos) {
        this.btReportesGastos = btReportesGastos;
    }

    public JButton getBtReportesVentas() {
        return btReportesVentas;
    }

    public void setBtReportesVentas(JButton btReportesVentas) {
        this.btReportesVentas = btReportesVentas;
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Lboofotogasto;
    private javax.swing.JButton btAgregarModi;
    private javax.swing.JButton btAgregarModiG;
    private javax.swing.JButton btCargarFotoG;
    private javax.swing.JButton btEliminarGastoC;
    private javax.swing.JButton btFecha;
    private javax.swing.JButton btFechaGASTO;
    private javax.swing.JButton btModiGastoC;
    private javax.swing.JButton btNuevoGC;
    private javax.swing.JButton btPrevisualizar;
    private javax.swing.JButton btProModif;
    private javax.swing.JButton btProdelete;
    private javax.swing.JButton btPronuevo;
    private javax.swing.JButton btReporteProductos;
    private javax.swing.JButton btReportesGastos;
    private javax.swing.JButton btReportesVentas;
    private javax.swing.JButton btSalir;
    private javax.swing.JButton btSalirG;
    private javax.swing.JButton btVerCategoria;
    private javax.swing.ButtonGroup btgCodProd;
    private javax.swing.JComboBox<String> cbFechasGastos;
    private javax.swing.JComboBox<String> cbFechasVentas;
    private javax.swing.JComboBox<String> cbProCate;
    private com.toedter.calendar.JDateChooser dtDesdeGasato;
    private com.toedter.calendar.JDateChooser dtDesdeVentas;
    private com.toedter.calendar.JDateChooser dtFecha;
    private com.toedter.calendar.JDateChooser dtHastaGasto;
    private com.toedter.calendar.JDateChooser dtHastaVentas;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JDialog jdGastos;
    private javax.swing.JDialog jdProductos;
    private javax.swing.JLabel lbErrores;
    private javax.swing.JLabel lbErroresGasto;
    private javax.swing.JLabel lbFotoG;
    private javax.swing.JLabel lbHastaVentas;
    private javax.swing.JLabel lbModificar;
    private javax.swing.JLabel lbMontostotalesGastos;
    private javax.swing.JLabel lbNuevo;
    private javax.swing.JLabel lbTitulo;
    private javax.swing.JLabel lbTotalProd;
    private javax.swing.JLabel lbTotalvendido;
    private javax.swing.JLabel lbTotalventas;
    private javax.swing.JLabel lbdesdeGastos;
    private javax.swing.JLabel lbhastaGastos;
    private javax.swing.JLabel lblDesdeVentas;
    private javax.swing.JLabel lboodesgasto;
    private javax.swing.JLabel lboopreciogasto;
    private javax.swing.JLabel lbopcionobligatoriaprecio;
    private javax.swing.JLabel lbopcionobligatorioselecco;
    private javax.swing.JLabel lbopcionovligatorianombre;
    private javax.swing.JLabel lbtotalGastos;
    private javax.swing.JRadioButton rbEditar;
    private javax.swing.JRadioButton rbGenerar;
    private javax.swing.JTable tabla_factura_registro;
    private javax.swing.JTable tbGastos;
    private javax.swing.JTable tbProductos;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtCodPro;
    private javax.swing.JTextPane txtPrevista;
    private javax.swing.JTextField txtPronombre;
    private javax.swing.JTextField txtProprecio;
    private javax.swing.JTextField txtcodG;
    private javax.swing.JTextArea txtdescripG;
    private javax.swing.JTextField txtprecioG;
    // End of variables declaration//GEN-END:variables
}
